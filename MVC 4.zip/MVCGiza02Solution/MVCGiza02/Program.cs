namespace MVCGiza02
{
    public class Program
    {
        // Main Point / etry Point :
        // CLR sgtart app from here .. 
        // Console app : Main { // CLR }
        // Mvc web app : Main : build web app ..
        // builder design pattern .. self
        public static void Main(string[] args)
        {
            // 1- Build we app with some configs ..
            var builder = WebApplication.CreateBuilder(args);

            // DbContext (Unmanaged resource)
            // Life time as a service : Design Pattern 
            // Dependency Injection
            // Add services to the container.
            builder.Services.AddControllersWithViews();

            var app = builder.Build();

            // 2- Handle req : 
            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
            }
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller}/{action}/{id?}");

            app.Run();
        }
    }
}
