using Microsoft.EntityFrameworkCore;
using MVCGiza02.Data.DbContexts;

namespace MVCGiza02.Models
{
    public class StudentBL
    {
        // open connection with DB
        DigitalDbContext context = new DigitalDbContext();

        // 1- Get all (Search by name + Filter by department + Pagination)
        public PagedResult<Student> GetAll(string? search, int? deptId, int page, int pageSize)
        {
            // Build the query step by step (nothing is executed yet)
            IQueryable<Student> query = context.Students.Include(S => S.Dept);

            // Search by name
            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(S => S.Name.Contains(search.Trim()));

            // Filter by department
            if (deptId.HasValue && deptId.Value > 0)
                query = query.Where(S => S.DeptId == deptId.Value);

            // Total count AFTER search/filter (needed for the pager)
            int total = query.Count();
            int totalPages = (int)Math.Ceiling(total / (double)pageSize);

            // keep the page number in a valid range
            if (page > totalPages) page = totalPages;
            if (page < 1) page = 1;

            // Pagination : skip previous pages, take the current page only
            List<Student> items = query
                .OrderBy(S => S.Id)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            return new PagedResult<Student>
            {
                Items = items,
                TotalCount = total,
                Page = page,
                PageSize = pageSize
            };
        }

        // 2- Get by id (with its department)
        public Student? GetById(int id)
        {
            return context.Students
                .Include(S => S.Dept)
                .FirstOrDefault(S => S.Id == id);
        }

        // 3- Add
        public void Add(Student student)
        {
            context.Students.Add(student);
            context.SaveChanges();
        }

        // 4- Save changes (Edit) : entity is tracked by this context
        public void SaveInDB()
        {
            context.SaveChanges();
        }

        // 5- Delete
        public void Delete(Student student)
        {
            context.Students.Remove(student);
            context.SaveChanges();
        }
    }
}
