﻿namespace MVCGiza02.Models
{
    // after .net 6 : 
    // Nullable ref types !!
    // represent business ...

    // required to store data about it !
    public class Employee
    {
        public int Id { get; set; }
        
        public string Name { get; set; } //ref //Non nullable
        public decimal Salary { get; set; }
        public string? Title { get; set; }
        public string Address { get; set; }

        // FK 
        public int DeptId { get; set; }

        // has a department
        public Department? Dept { get; set; }
    }
}
