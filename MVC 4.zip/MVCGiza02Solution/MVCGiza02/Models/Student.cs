using System.ComponentModel.DataAnnotations;

namespace MVCGiza02.Models
{
    public class Student
    {
        public int Id { get; set; }

        public string Name { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }

        // FK
        public int DeptId { get; set; }

        // Student belongs to a department
        public Department? Dept { get; set; }
    }
}
