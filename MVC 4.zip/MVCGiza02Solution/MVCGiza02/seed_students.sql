-- شغّله على الداتابيز Digital بعد ما تعمل Update-Database وتضيف كام Department
USE Digital;
DECLARE @i INT = 1;
WHILE @i <= 25
BEGIN
    INSERT INTO Students (Name, Age, Address, DeptId)
    SELECT 'Student ' + CAST(@i AS NVARCHAR(10)),
           18 + (@i % 10),
           'Giza',
           (SELECT TOP 1 Id FROM Departments ORDER BY NEWID());
    SET @i += 1;
END
