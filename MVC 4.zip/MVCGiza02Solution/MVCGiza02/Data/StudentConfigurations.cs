using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MVCGiza02.Models;

namespace MVCGiza02.Data
{
    public class StudentConfigurations : IEntityTypeConfiguration<Student>
    {
        public void Configure(EntityTypeBuilder<Student> builder)
        {
            builder.ToTable("Students");

            builder.HasKey(S => S.Id);

            builder.Property(S => S.Name)
                .HasMaxLength(100);
            builder.Property(S => S.Address)
                .HasMaxLength(50);

            // relationship
            builder.HasOne(S => S.Dept)
                .WithMany(D => D.Students)
                .HasForeignKey(S => S.DeptId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
