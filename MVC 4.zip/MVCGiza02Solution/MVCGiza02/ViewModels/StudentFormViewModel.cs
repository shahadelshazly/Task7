using MVCGiza02.Models;
using System.ComponentModel.DataAnnotations;

namespace MVCGiza02.ViewModels
{
    // Used by Add + Edit : student data + list of departments to select from
    public class StudentFormViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Name must be between 3 and 100 characters")]
        [Display(Name = "Full Name")]
        public string Name { get; set; }

        [Range(16, 60, ErrorMessage = "Age must be between 16 and 60")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Address is required")]
        [StringLength(50, ErrorMessage = "Address can't exceed 50 characters")]
        public string Address { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Please select a department")]
        [Display(Name = "Department")]
        public int DeptId { get; set; }

        // nullable => not validated on post
        public List<Department>? DeptList { get; set; }
    }
}
