using MVCGiza02.Models;

namespace MVCGiza02.ViewModels
{
    // Sources : Students (one page) - Departments (filter list) - search/filter/paging info
    public class StudentIndexViewModel
    {
        public List<Student> Students { get; set; } = new List<Student>();
        public List<Department> Departments { get; set; } = new List<Department>();

        // current search / filter
        public string? Search { get; set; }
        public int? DeptId { get; set; }

        // paging
        public int Page { get; set; }
        public int TotalPages { get; set; }
        public int TotalCount { get; set; }

        public bool HasPrevious => Page > 1;
        public bool HasNext => Page < TotalPages;
    }
}
