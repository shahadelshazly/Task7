using Microsoft.AspNetCore.Mvc;
using MVCGiza02.Models;
using MVCGiza02.ViewModels;

namespace MVCGiza02.Controllers
{
    public class StudentController : Controller
    {
        StudentBL studentBL = new StudentBL();
        DepartmentBL departmentBL = new DepartmentBL();

        const int PageSize = 5;

        // ---------------- GetAll ----------------
        // /Student/Index?search=ali&deptId=2&page=2
        public IActionResult Index(string? search, int? deptId, int page = 1)
        {
            // Sources
            PagedResult<Student> result = studentBL.GetAll(search, deptId, page, PageSize);
            List<Department> depts = departmentBL.GetForDropdown();

            // Destination + mapping
            StudentIndexViewModel vm = new StudentIndexViewModel
            {
                Students = result.Items,
                Departments = depts,
                Search = search,
                DeptId = deptId,
                Page = result.Page,
                TotalPages = result.TotalPages,
                TotalCount = result.TotalCount
            };

            return View("Index", vm);
        }

        // ---------------- GetById ----------------
        // /Student/Details/3
        public IActionResult Details(int id)
        {
            Student? student = studentBL.GetById(id);
            if (student == null) return NotFound();

            return View("Details", student);
        }

        // ---------------- Add ----------------
        // 1- open form (with all departments)
        public IActionResult Add()
        {
            StudentFormViewModel vm = new StudentFormViewModel
            {
                DeptList = departmentBL.GetForDropdown()
            };
            return View("Add", vm);
        }

        // 2- save to DB
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SaveAdd(StudentFormViewModel vm)
        {
            if (ModelState.IsValid)
            {
                Student student = new Student
                {
                    Name = vm.Name,
                    Age = vm.Age,
                    Address = vm.Address,
                    DeptId = vm.DeptId
                };
                studentBL.Add(student);
                return RedirectToAction(nameof(Index));
            }

            // invalid : reload departments and return to the form
            vm.DeptList = departmentBL.GetForDropdown();
            return View("Add", vm);
        }

        // ---------------- Edit ----------------
        // 1- open form filled with student data + all departments
        // /Student/Edit/3
        public IActionResult Edit(int id)
        {
            Student? student = studentBL.GetById(id);
            if (student == null) return NotFound();

            StudentFormViewModel vm = new StudentFormViewModel
            {
                Id = student.Id,
                Name = student.Name,
                Age = student.Age,
                Address = student.Address,
                DeptId = student.DeptId,
                DeptList = departmentBL.GetForDropdown()
            };
            return View("Edit", vm);
        }

        // 2- save changes
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SaveEdit(StudentFormViewModel vm)
        {
            if (ModelState.IsValid)
            {
                Student? old = studentBL.GetById(vm.Id);
                if (old == null) return NotFound();

                old.Name = vm.Name;
                old.Age = vm.Age;
                old.Address = vm.Address;
                old.DeptId = vm.DeptId;
                studentBL.SaveInDB();

                return RedirectToAction(nameof(Index));
            }

            vm.DeptList = departmentBL.GetForDropdown();
            return View("Edit", vm);
        }

        // ---------------- Delete ----------------
        // 1- direct to warning view
        // /Student/Delete/3
        public IActionResult Delete(int id)
        {
            Student? student = studentBL.GetById(id);
            if (student == null) return NotFound();

            return View("Delete", student);
        }

        // 2- confirm delete
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ConfirmDelete(int id)
        {
            Student? student = studentBL.GetById(id);
            if (student == null) return NotFound();

            studentBL.Delete(student);
            return RedirectToAction(nameof(Index));
        }
    }
}
