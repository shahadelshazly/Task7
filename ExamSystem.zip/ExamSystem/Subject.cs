using System;
using System.Collections.Generic;

namespace ExamSystem
{
    
    public enum ExamMode
    {
        Queued,
        Starting,
        Finished
    }
    public class ExamEventArgs : EventArgs
    {
        public Exam Exam { get; }
        public ExamMode OldMode { get; }
        public ExamMode NewMode { get; }

        public ExamEventArgs(Exam exam, ExamMode oldMode, ExamMode newMode)
        {
            Exam = exam;
            OldMode = oldMode;
            NewMode = newMode;
        }
    }

    public delegate void ExamModeChangedHandler(object sender, ExamEventArgs e);

    public class Subject : ICloneable, IComparable<Subject>
    {
        private static int _nextId = 0;

        public int Id { get; private set; }
        public string Name { get; set; }
        public int CreditHours { get; set; }
        public List<Student> Students { get; private set; }

        public event ExamModeChangedHandler ExamStarting;

        public Subject() : this("Unknown Subject") { }
        public Subject(string name) : this(name, 3) { }
        public Subject(string name, int creditHours)
        {
            Id = ++_nextId;
            Name = name;
            CreditHours = creditHours;
            Students = new List<Student>();
        }

        public void Enroll(Student student)
        {
            if (student == null || Students.Contains(student)) return;
            Students.Add(student);
            ExamStarting += student.OnExamStarting;   
        }

        
        public void OnExamModeChanged(object sender, ExamEventArgs e)
        {
            if (e.NewMode == ExamMode.Starting)
                ExamStarting?.Invoke(this, e);
        }

        public object Clone()
        {
            Subject copy = (Subject)MemberwiseClone();
            copy.Id = ++_nextId;
            copy.Students = new List<Student>();   
            copy.ExamStarting = null;
            return copy;
        }

        public int CompareTo(Subject other)
        {
            if (other == null) return 1;
            return string.Compare(Name, other.Name, StringComparison.Ordinal);
        }

        public override string ToString() => $"{Name} ({CreditHours} credit hours, {Students.Count} students)";

        public override bool Equals(object obj) => obj is Subject other && Name == other.Name;

        public override int GetHashCode() => Name == null ? 0 : Name.GetHashCode();
    }

    public class Student : IComparable<Student>
    {
        private static int _nextId = 0;

        public int Id { get; }
        public string Name { get; set; }

        public Student() : this("Unknown Student") { }
        public Student(string name)
        {
            Id = ++_nextId;
            Name = name;
        }

        public void OnExamStarting(object sender, ExamEventArgs e)
        {
            Console.WriteLine($"   [Notification to {Name}] The {e.Exam.ExamTypeName} of '{e.Exam.Subject.Name}' is now STARTING!");
        }

        public int CompareTo(Student other)
        {
            if (other == null) return 1;
            return string.Compare(Name, other.Name, StringComparison.Ordinal);
        }

        public override string ToString() => $"Student #{Id}: {Name}";

        public override bool Equals(object obj) => obj is Student other && Id == other.Id;

        public override int GetHashCode() => Id.GetHashCode();
    }
}
