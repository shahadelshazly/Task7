using System;
using System.Collections.Generic;
using System.Linq;

namespace ExamSystem
{
    public abstract class Exam : ICloneable, IComparable<Exam>
    {
        public int TimeInMinutes { get; set; }
        public Subject Subject { get; private set; }
        public QuestionList<Question> Questions { get; private set; }

        public Dictionary<Question, List<int>> QuestionAnswerDictionary { get; private set; }

        protected Dictionary<Question, List<int>> StudentAnswers { get; private set; }

        public int NumberOfQuestions => Questions.Count;
        public int TotalMarks => Questions.Sum(q => q.Marks);

        public abstract string ExamTypeName { get; }

      
        private ExamMode _mode = ExamMode.Queued;

        public ExamMode Mode
        {
            get => _mode;
            set
            {
                if (_mode == value) return;
                ExamMode old = _mode;
                _mode = value;
                ModeChanged?.Invoke(this, new ExamEventArgs(this, old, value));
            }
        }

        public event ExamModeChangedHandler ModeChanged;

        protected Exam(Subject subject) : this(subject, 30) { }

        protected Exam(Subject subject, int timeInMinutes)
            : this(subject, timeInMinutes, new QuestionList<Question>()) { }

        protected Exam(Subject subject, int timeInMinutes, QuestionList<Question> questions)
        {
            if (subject == null) throw new ArgumentNullException(nameof(subject));

            Subject = subject;
            TimeInMinutes = timeInMinutes;
            Questions = questions;
            QuestionAnswerDictionary = new Dictionary<Question, List<int>>();
            StudentAnswers = new Dictionary<Question, List<int>>();

            foreach (Question q in questions)
                QuestionAnswerDictionary[q] = new List<int>(q.CorrectAnswerIds);

            ModeChanged += subject.OnExamModeChanged;
        }

        public bool AddQuestion(Question question)
        {
            if (question == null || Questions.Contains(question)) return false;
            Questions.Add(question);  
            QuestionAnswerDictionary[question] = new List<int>(question.CorrectAnswerIds);
            return true;
        }

        public abstract void ShowExam();

        protected void AskQuestions()
        {
            StudentAnswers.Clear();
            foreach (Question q in Questions)
            {
                q.Show();

                List<int> parsed = null;
                while (parsed == null)
                {
                    Console.Write("Your answer: ");
                    string input = Console.ReadLine();
                    if (input == null)  
                    {
                        parsed = new List<int>();
                        break;
                    }
                    parsed = q.ParseAnswer(input);
                    if (parsed == null)
                        Console.WriteLine("   Invalid answer, try again.");
                }
                StudentAnswers[q] = parsed;
            }
        }

        protected int CalculateScore()
        {
            int score = 0;
            foreach (var pair in QuestionAnswerDictionary)
            {
                StudentAnswers.TryGetValue(pair.Key, out List<int> given);
                if (given != null && new HashSet<int>(given).SetEquals(pair.Value))
                    score += pair.Key.Marks;
            }
            return score;
        }

        protected void PrintExamHeader()
        {
            Console.WriteLine();
            Console.WriteLine("==========================================");
            Console.WriteLine($" {ExamTypeName} - {Subject.Name}");
            Console.WriteLine($" Time: {TimeInMinutes} min | Questions: {NumberOfQuestions} | Total marks: {TotalMarks}");
            Console.WriteLine("==========================================");
        }

        public object Clone()
        {
            Exam copy = (Exam)MemberwiseClone();
            copy.QuestionAnswerDictionary = new Dictionary<Question, List<int>>();
            foreach (var p in QuestionAnswerDictionary)
                copy.QuestionAnswerDictionary[p.Key] = new List<int>(p.Value);
            copy.StudentAnswers = new Dictionary<Question, List<int>>();
            copy.ModeChanged = null;               
            copy.ModeChanged += Subject.OnExamModeChanged;
            copy._mode = ExamMode.Queued;
            return copy;
        }
        public int CompareTo(Exam other)
        {
            if (other == null) return 1;
            int c = TotalMarks.CompareTo(other.TotalMarks);
            return c != 0 ? c : TimeInMinutes.CompareTo(other.TimeInMinutes);
        }

        public override string ToString()
            => $"{ExamTypeName} | Subject: {Subject.Name} | Time: {TimeInMinutes} min | Questions: {NumberOfQuestions} | Mode: {Mode}";

        public override bool Equals(object obj)
        {
            return obj is Exam other
                && GetType() == other.GetType()
                && Subject.Equals(other.Subject)
                && TimeInMinutes == other.TimeInMinutes
                && NumberOfQuestions == other.NumberOfQuestions;
        }

        public override int GetHashCode()
            => HashCode.Combine(GetType(), Subject, TimeInMinutes, NumberOfQuestions);
    }
    public class PracticeExam : Exam
    {
        public override string ExamTypeName => "Practice Exam";

        public PracticeExam(Subject subject) : base(subject) { }
        public PracticeExam(Subject subject, int timeInMinutes) : base(subject, timeInMinutes) { }
        public PracticeExam(Subject subject, int timeInMinutes, QuestionList<Question> questions)
            : base(subject, timeInMinutes, questions) { }

        public override void ShowExam()
        {
            PrintExamHeader();
            AskQuestions();

            Console.WriteLine();
            Console.WriteLine("------------- Right Answers -------------");
            foreach (Question q in Questions)
            {
                bool ok = q.IsCorrect(StudentAnswers[q]);
                Console.WriteLine($"{q.Header}: {q.Body}");
                Console.WriteLine($"   Your answer   : {q.DescribeAnswers(StudentAnswers[q])}  {(ok ? "(correct)" : "(wrong)")}");
                Console.WriteLine($"   Right answer  : {q.DescribeAnswers(QuestionAnswerDictionary[q])}");
            }
            Console.WriteLine();
            Console.WriteLine($"Your score: {CalculateScore()} / {TotalMarks}");
        }
    }
    public class FinalExam : Exam
    {
        public override string ExamTypeName => "Final Exam";

        public FinalExam(Subject subject) : base(subject) { }
        public FinalExam(Subject subject, int timeInMinutes) : base(subject, timeInMinutes) { }
        public FinalExam(Subject subject, int timeInMinutes, QuestionList<Question> questions)
            : base(subject, timeInMinutes, questions) { }

        public override void ShowExam()
        {
            PrintExamHeader();
            AskQuestions();

            Console.WriteLine();
            Console.WriteLine("------------- Your Submitted Answers -------------");
            foreach (Question q in Questions)
            {
                Console.WriteLine($"{q.Header}: {q.Body}");
                Console.WriteLine($"   Your answer: {q.DescribeAnswers(StudentAnswers[q])}");
            }
            Console.WriteLine();
            Console.WriteLine("Answers submitted. Results will be announced later.");
        }
    }
}
