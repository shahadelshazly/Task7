using System;
using System.Collections.Generic;
using System.Linq;

namespace ExamSystem
{
    public abstract class Question : ICloneable, IComparable<Question>
    {
        private static int _nextId = 0;

        public int Id { get; private set; }
        public string Header { get; set; }
        public string Body { get; set; }
        public int Marks { get; set; }
        public AnswerList Answers { get; protected set; }

        public List<int> CorrectAnswerIds { get; protected set; }

        protected Question() : this("No Header", "No Body") { }
        protected Question(string header, string body) : this(header, body, 1) { }
        protected Question(string header, string body, int marks)
        {
            Id = ++_nextId;
            Header = header;
            Body = body;
            Marks = marks;
            Answers = new AnswerList();
            CorrectAnswerIds = new List<int>();
        }

        public abstract void Show();

        public abstract List<int> ParseAnswer(string input);

        public abstract string TypeName { get; }

        protected void ShowHeaderAndBody()
        {
            Console.WriteLine();
            Console.WriteLine($"--- {Header} ({Marks} mark{(Marks > 1 ? "s" : "")}) ---");
            Console.WriteLine(Body);
        }

        protected static List<int> ParseIds(string input)
        {
            List<int> result = new List<int>();
            if (string.IsNullOrWhiteSpace(input)) return null;

            foreach (string part in input.Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                if (!int.TryParse(part, out int id)) return null;
                result.Add(id);
            }
            return result.Distinct().ToList();
        }

        protected bool AllIdsExist(List<int> ids)
        {
            return ids != null && ids.Count > 0 && ids.All(id => Answers.Any(a => a.Id == id));
        }

        public bool IsCorrect(List<int> given)
        {
            if (given == null) return false;
            return new HashSet<int>(given).SetEquals(CorrectAnswerIds);
        }

       
        public string DescribeAnswers(IEnumerable<int> ids)
        {
            if (ids == null) return "(no answer)";
            var texts = ids.Select(id => Answers.FirstOrDefault(a => a.Id == id))
                           .Where(a => a != null)
                           .Select(a => a.ToString())
                           .ToList();
            return texts.Count == 0 ? "(no answer)" : string.Join(" | ", texts);
        }

        public object Clone()
        {
            Question copy = (Question)MemberwiseClone();
            copy.Id = ++_nextId;
            copy.Answers = new AnswerList(Answers.Select(a => (Answer)a.Clone()));
            copy.CorrectAnswerIds = new List<int>(CorrectAnswerIds);
            return copy;
        }

        public int CompareTo(Question other)
        {
            if (other == null) return 1;
            int c = Marks.CompareTo(other.Marks);
            return c != 0 ? c : string.Compare(Header, other.Header, StringComparison.Ordinal);
        }

        public override string ToString() => $"[{TypeName}] {Header} ({Marks} marks): {Body}";

        public override bool Equals(object obj)
        {
            return obj is Question other
                && GetType() == other.GetType()
                && Header == other.Header
                && Body == other.Body
                && Marks == other.Marks;
        }

        public override int GetHashCode() => HashCode.Combine(GetType(), Header, Body, Marks);
    }

    public class TrueFalseQuestion : Question
    {
        public override string TypeName => "True/False";

        public TrueFalseQuestion(string header, string body, bool correctValue)
            : this(header, body, 1, correctValue) { }

        public TrueFalseQuestion(string header, string body, int marks, bool correctValue)
            : base(header, body, marks)
        {
            Answers.Add("True");
            Answers.Add("False");
            CorrectAnswerIds.Add(correctValue ? 1 : 2);
        }

        public override void Show()
        {
            ShowHeaderAndBody();
            Console.WriteLine("   (True or False - enter 1 or 2)");
            Console.Write(Answers.ToString());
        }

        public override List<int> ParseAnswer(string input)
        {
            string t = (input ?? "").Trim().ToLower();
            if (t == "t" || t == "true") return new List<int> { 1 };
            if (t == "f" || t == "false") return new List<int> { 2 };

            List<int> ids = ParseIds(input);
            return (ids != null && ids.Count == 1 && AllIdsExist(ids)) ? ids : null;
        }
    }

    public class ChooseOneQuestion : Question
    {
        public override string TypeName => "Choose One";

        public ChooseOneQuestion(string header, string body, IEnumerable<string> choices, int correctChoice)
            : this(header, body, 1, choices, correctChoice) { }

        public ChooseOneQuestion(string header, string body, int marks, IEnumerable<string> choices, int correctChoice)
            : base(header, body, marks)
        {
            foreach (string c in choices) Answers.Add(c);
            CorrectAnswerIds.Add(correctChoice);   
        }

        public override void Show()
        {
            ShowHeaderAndBody();
            Console.WriteLine("   (Choose ONE answer - enter its number)");
            Console.Write(Answers.ToString());
        }

        public override List<int> ParseAnswer(string input)
        {
            List<int> ids = ParseIds(input);
            return (ids != null && ids.Count == 1 && AllIdsExist(ids)) ? ids : null;
        }
    }

    public class ChooseAllQuestion : Question
    {
        public override string TypeName => "Choose All";

        public ChooseAllQuestion(string header, string body, IEnumerable<string> choices, IEnumerable<int> correctChoices)
            : this(header, body, 1, choices, correctChoices) { }

        public ChooseAllQuestion(string header, string body, int marks, IEnumerable<string> choices, IEnumerable<int> correctChoices)
            : base(header, body, marks)
        {
            foreach (string c in choices) Answers.Add(c);
            CorrectAnswerIds.AddRange(correctChoices);   
        }

        public override void Show()
        {
            ShowHeaderAndBody();
            Console.WriteLine("   (Choose ALL correct answers - numbers separated by commas, e.g. 1,3)");
            Console.Write(Answers.ToString());
        }

        public override List<int> ParseAnswer(string input)
        {
            List<int> ids = ParseIds(input);
            return AllIdsExist(ids) ? ids : null;
        }
    }
}
