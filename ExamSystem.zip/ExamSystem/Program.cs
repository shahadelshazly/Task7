using System;
using System.Collections.Generic;

namespace ExamSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Subject csharp = new Subject("C# Programming", 4);
            csharp.Enroll(new Student("Ahmed"));
            csharp.Enroll(new Student("Sara"));
            csharp.Enroll(new Student("Omar"));

            PracticeExam practiceExam = new PracticeExam(csharp, 20);
            FinalExam finalExam = new FinalExam(csharp, 60);

            Question q1 = new TrueFalseQuestion("Q1", "C# is an object oriented language.", 1, true);
            Question q2 = new ChooseOneQuestion("Q2", "Which keyword is used to inherit from a class?", 2,
                new[] { "extends", ":", "inherits", "implements" }, 2);
            Question q3 = new ChooseAllQuestion("Q3", "Which of these are value types?", 3,
                new[] { "int", "string", "bool", "double" }, new[] { 1, 3, 4 });

            practiceExam.AddQuestion(q1);
            practiceExam.AddQuestion(q2);
            practiceExam.AddQuestion(q3);

            finalExam.AddQuestion((Question)q1.Clone());
            finalExam.AddQuestion((Question)q2.Clone());
            finalExam.AddQuestion((Question)q3.Clone());

            Console.WriteLine("Welcome to the Examination System");
            Console.WriteLine(practiceExam);
            Console.WriteLine(finalExam);

            Exam selected = null;
            while (selected == null)
            {
                Console.WriteLine();
                Console.WriteLine("Select exam type:");
                Console.WriteLine("  1) Practice Exam");
                Console.WriteLine("  2) Final Exam");
                Console.Write("Your choice: ");
                string choice = Console.ReadLine();
                if (choice == null) return;   

                if (choice.Trim() == "1") selected = practiceExam;
                else if (choice.Trim() == "2") selected = finalExam;
                else Console.WriteLine("Invalid choice.");
            }

            Console.WriteLine();
            Console.WriteLine($"Exam mode: {selected.Mode} -> Starting");
            selected.Mode = ExamMode.Starting;

            selected.ShowExam();

            selected.Mode = ExamMode.Finished;
            Console.WriteLine();
            Console.WriteLine($"Exam mode is now: {selected.Mode}");

            Console.WriteLine();
            Console.WriteLine("---- Extra demo ----");
            Console.WriteLine($"practiceExam.CompareTo(finalExam) = {practiceExam.CompareTo(finalExam)}");
            Console.WriteLine($"q1.Equals(q1.Clone())            = {q1.Equals(q1.Clone())}");
            Console.WriteLine($"Questions log file: {practiceExam.Questions.FilePath}");
            Console.WriteLine(practiceExam.Questions.ReadLog());
        }
    }
}
