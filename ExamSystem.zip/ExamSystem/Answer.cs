using System;
using System.Collections.Generic;
using System.Text;

namespace ExamSystem
{
    public class Answer : ICloneable, IComparable<Answer>
    {
        public int Id { get; set; }
        public string Text { get; set; }

        public Answer() : this("No text") { }
        public Answer(string text) : this(0, text) { }
        public Answer(int id, string text)
        {
            Id = id;
            Text = text;
        }

        public object Clone() => new Answer(Id, Text);

        public int CompareTo(Answer other)
        {
            if (other == null) return 1;
            return Id.CompareTo(other.Id);
        }

        public override string ToString() => $"{Id}. {Text}";

        public override bool Equals(object obj)
        {
            return obj is Answer other && Id == other.Id && Text == other.Text;
        }

        public override int GetHashCode() => HashCode.Combine(Id, Text);
    }
    public class AnswerList : List<Answer>
    {
        public AnswerList() : base() { }
        public AnswerList(IEnumerable<Answer> answers) : base(answers) { }
        public void Add(string text)
        {
            Add(new Answer(Count + 1, text));
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Answer a in this)
                sb.AppendLine("   " + a);
            return sb.ToString();
        }
    }
}
