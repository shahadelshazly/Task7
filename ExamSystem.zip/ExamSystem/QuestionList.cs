using System;
using System.Collections.Generic;
using System.IO;

namespace ExamSystem
{
    public class QuestionList<T> : List<T> where T : Question
    {
        private static int _listCounter = 0;
        public string FilePath { get; private set; }
        public QuestionList() : this($"QuestionList_{++_listCounter}.txt") { }
        public QuestionList(string filePath) : base()
        {
            FilePath = filePath;
         
            using (StreamWriter writer = new StreamWriter(FilePath, false))
            {
                writer.WriteLine($"=== Question log created at {DateTime.Now} ===");
            }
        }

        public new void Add(T question)
        {
            base.Add(question);
            using (StreamWriter writer = new StreamWriter(FilePath, true))
            {
                writer.WriteLine(question.ToString());
            }
        }

        public string ReadLog()
        {
            using (StreamReader reader = new StreamReader(FilePath))
            {
                return reader.ReadToEnd();
            }
        }
    }
}
