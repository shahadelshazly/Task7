using System.ComponentModel.DataAnnotations;

namespace StudentMvc.Models
{
    public class Student
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Name must be 3 to 50 characters")]
        [RegularExpression(@"^[\p{L} .'-]+$", ErrorMessage = "Name can contain letters and spaces only")]
        public string Name { get; set; } = string.Empty;

        [Range(16, 60, ErrorMessage = "Age must be between 16 and 60")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Address is required")]
        [StringLength(100)]
        public string Address { get; set; } = string.Empty;

        // Foreign key -> the student's department
        [Display(Name = "Department")]
        [Required(ErrorMessage = "Please select a department")]
        public int? DepartmentId { get; set; }

        // Navigation property (nullable so it is not validated on form submit)
        public Department? Department { get; set; }
    }
}
