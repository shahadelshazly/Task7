using System.ComponentModel.DataAnnotations;

namespace StudentMvc.Models
{
    public class Department
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Department name is required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Name must be 2 to 50 characters")]
        [Display(Name = "Department Name")]
        public string Name { get; set; } = string.Empty;

        // One department has many students
        public List<Student> Students { get; set; } = new();
    }
}
