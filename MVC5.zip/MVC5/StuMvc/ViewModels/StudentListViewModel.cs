using StudentMvc.Models;

namespace StudentMvc.ViewModels
{
    // Everything the GetAll page needs: the students of the current page,
    // the departments for the filter dropdown, and the paging/search/filter state.
    public class StudentListViewModel
    {
        public List<Student> Students { get; set; } = new();
        public List<Department> Departments { get; set; } = new();

        public string? Search { get; set; }
        public int? DepartmentId { get; set; }

        public int Page { get; set; } = 1;
        public int TotalPages { get; set; } = 1;
        public int TotalCount { get; set; }
    }
}
