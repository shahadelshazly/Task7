using Microsoft.EntityFrameworkCore;
using StudentMvc.Models;

namespace StudentMvc.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Student> Students => Set<Student>();
        public DbSet<Department> Departments => Set<Department>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Department>().HasData(
                new Department { Id = 1, Name = "Computer Science" },
                new Department { Id = 2, Name = "Information Systems" },
                new Department { Id = 3, Name = "Software Engineering" });

            // Sample students so you can test pagination / search / filter immediately
            modelBuilder.Entity<Student>().HasData(
                new Student { Id = 1,  Name = "Ahmed Ali",     Age = 20, Address = "Cairo",      DepartmentId = 1 },
                new Student { Id = 2,  Name = "Sara Hassan",   Age = 21, Address = "Giza",       DepartmentId = 2 },
                new Student { Id = 3,  Name = "Omar Khaled",   Age = 22, Address = "Alexandria", DepartmentId = 3 },
                new Student { Id = 4,  Name = "Mona Samir",    Age = 19, Address = "Cairo",      DepartmentId = 1 },
                new Student { Id = 5,  Name = "Youssef Adel",  Age = 23, Address = "Mansoura",   DepartmentId = 2 },
                new Student { Id = 6,  Name = "Nour Ibrahim",  Age = 20, Address = "Tanta",      DepartmentId = 3 },
                new Student { Id = 7,  Name = "Ahmed Mostafa", Age = 24, Address = "Giza",       DepartmentId = 1 },
                new Student { Id = 8,  Name = "Hana Tarek",    Age = 21, Address = "Cairo",      DepartmentId = 2 },
                new Student { Id = 9,  Name = "Khaled Samy",   Age = 22, Address = "Aswan",      DepartmentId = 1 },
                new Student { Id = 10, Name = "Laila Fathy",   Age = 20, Address = "Luxor",      DepartmentId = 3 },
                new Student { Id = 11, Name = "Mahmoud Reda",  Age = 25, Address = "Cairo",      DepartmentId = 1 },
                new Student { Id = 12, Name = "Salma Nabil",   Age = 19, Address = "Alexandria", DepartmentId = 2 });
        }
    }
}
