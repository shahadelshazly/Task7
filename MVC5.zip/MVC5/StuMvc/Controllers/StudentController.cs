using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentMvc.Data;
using StudentMvc.Models;
using StudentMvc.ViewModels;

namespace StudentMvc.Controllers
{
    public class StudentController : Controller
    {
        private const int PageSize = 5;
        private readonly AppDbContext _db;

        public StudentController(AppDbContext db)
        {
            _db = db;
        }

        // ============ GetAll: pagination + search by name + filter by department ============
        public async Task<IActionResult> GetAll(string? search, int? departmentId, int page = 1)
        {
            IQueryable<Student> query = _db.Students.Include(s => s.Department);

            // Search by student name
            if (!string.IsNullOrWhiteSpace(search))
            {
                string term = search.Trim();
                query = query.Where(s => EF.Functions.Like(s.Name, $"%{term}%"));
            }

            // Filter by department
            if (departmentId.HasValue)
            {
                query = query.Where(s => s.DepartmentId == departmentId.Value);
            }

            // Pagination
            int totalCount = await query.CountAsync();
            int totalPages = Math.Max(1, (int)Math.Ceiling(totalCount / (double)PageSize));
            page = Math.Clamp(page, 1, totalPages);

            List<Student> students = await query
                .OrderBy(s => s.Id)
                .Skip((page - 1) * PageSize)
                .Take(PageSize)
                .ToListAsync();

            var vm = new StudentListViewModel
            {
                Students = students,
                Departments = await _db.Departments.OrderBy(d => d.Name).ToListAsync(),
                Search = search,
                DepartmentId = departmentId,
                Page = page,
                TotalPages = totalPages,
                TotalCount = totalCount
            };

            return View(vm);
        }

        // ============ GetById ============
        public async Task<IActionResult> GetById(int id)
        {
            Student? student = await _db.Students
                .Include(s => s.Department)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (student == null) return NotFound();
            return View(student);
        }

        // ============ Add ============
        [HttpGet]
        public async Task<IActionResult> Add()
        {
            await LoadDepartments();
            return View(new Student());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(Student student)
        {
            await ValidateDepartment(student);

            if (!ModelState.IsValid)
            {
                await LoadDepartments(student.DepartmentId);
                return View(student);
            }

            _db.Students.Add(student);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(GetAll));
        }

        // ============ Edit ============
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            Student? student = await _db.Students.FindAsync(id);
            if (student == null) return NotFound();

            await LoadDepartments(student.DepartmentId);
            return View(student);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Student student)
        {
            if (id != student.Id) return BadRequest();

            await ValidateDepartment(student);

            if (!ModelState.IsValid)
            {
                await LoadDepartments(student.DepartmentId);
                return View(student);
            }

            _db.Students.Update(student);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(GetAll));
        }

        // ============ Delete ============
        // GET goes DIRECTLY to the warning view (nothing is deleted yet)
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            Student? student = await _db.Students
                .Include(s => s.Department)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (student == null) return NotFound();
            return View(student);
        }

        // The real delete happens only after the user confirms in the warning view
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            Student? student = await _db.Students.FindAsync(id);
            if (student != null)
            {
                _db.Students.Remove(student);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(GetAll));
        }

        // Server-side check: the selected department must really exist in the database
        private async Task ValidateDepartment(Student student)
        {
            if (student.DepartmentId.HasValue &&
                !await _db.Departments.AnyAsync(d => d.Id == student.DepartmentId.Value))
            {
                ModelState.AddModelError(nameof(Student.DepartmentId), "Selected department does not exist");
            }
        }

        // Fills the departments dropdown used by Add and Edit
        private async Task LoadDepartments(int? selectedId = null)
        {
            var departments = await _db.Departments.OrderBy(d => d.Name).ToListAsync();
            ViewBag.Departments = new SelectList(departments, "Id", "Name", selectedId);
        }
    }
}
