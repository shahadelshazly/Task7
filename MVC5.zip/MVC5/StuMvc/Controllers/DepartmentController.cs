using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentMvc.Data;
using StudentMvc.Models;

namespace StudentMvc.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly AppDbContext _db;

        public DepartmentController(AppDbContext db)
        {
            _db = db;
        }

        // ============ GetAll ============
        public async Task<IActionResult> GetAll()
        {
            List<Department> departments = await _db.Departments
                .Include(d => d.Students)
                .OrderBy(d => d.Name)
                .ToListAsync();
            return View(departments);
        }

        // ============ GetById ============
        public async Task<IActionResult> GetById(int id)
        {
            Department? department = await _db.Departments
                .Include(d => d.Students)
                .FirstOrDefaultAsync(d => d.Id == id);

            if (department == null) return NotFound();
            return View(department);
        }

        // ============ Add ============
        [HttpGet]
        public IActionResult Add()
        {
            return View(new Department());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(Department department)
        {
            // Custom validation: department names must be unique
            if (await _db.Departments.AnyAsync(d => d.Name == department.Name))
                ModelState.AddModelError(nameof(Department.Name), "A department with this name already exists");

            if (!ModelState.IsValid) return View(department);

            _db.Departments.Add(department);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(GetAll));
        }

        // ============ Edit ============
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            Department? department = await _db.Departments.FindAsync(id);
            if (department == null) return NotFound();
            return View(department);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Department department)
        {
            if (id != department.Id) return BadRequest();

            // Unique name, ignoring the department we are editing
            if (await _db.Departments.AnyAsync(d => d.Name == department.Name && d.Id != department.Id))
                ModelState.AddModelError(nameof(Department.Name), "A department with this name already exists");

            if (!ModelState.IsValid) return View(department);

            _db.Departments.Update(department);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(GetAll));
        }

        // ============ Delete (warning view first) ============
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            Department? department = await _db.Departments
                .Include(d => d.Students)
                .FirstOrDefaultAsync(d => d.Id == id);

            if (department == null) return NotFound();
            return View(department);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            Department? department = await _db.Departments
                .Include(d => d.Students)
                .FirstOrDefaultAsync(d => d.Id == id);

            if (department == null) return RedirectToAction(nameof(GetAll));

            // A department that still has students cannot be deleted
            if (department.Students.Any())
                return RedirectToAction(nameof(Delete), new { id });

            _db.Departments.Remove(department);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(GetAll));
        }
    }
}
